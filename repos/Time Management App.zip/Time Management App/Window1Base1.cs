﻿namespace Time_Management_App
{
    public abstract class Window1Base1
    {
        private abstract void btn_close_Click(object sender, System.Windows.RoutedEventArgs e);
    }
}