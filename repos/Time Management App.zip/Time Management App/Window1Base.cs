﻿namespace Time_Management_App
{
    public class Window1Base
    {
    }
}