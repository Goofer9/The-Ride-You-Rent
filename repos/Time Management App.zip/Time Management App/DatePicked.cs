﻿using System;

namespace Time_Management_App
{
    internal class DatePicked
    {
        internal static ReadOnlySpan<char> Text;
    }
}